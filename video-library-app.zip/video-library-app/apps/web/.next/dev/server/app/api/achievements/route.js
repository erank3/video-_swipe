var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/achievements/route.js")
R.c("server/chunks/node_modules_next_7afb9470._.js")
R.c("server/chunks/[root-of-the-server]__90197ed4._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_achievements_route_actions_e311976f.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/apps/web/app/api/achievements/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/apps/web/app/api/achievements/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
