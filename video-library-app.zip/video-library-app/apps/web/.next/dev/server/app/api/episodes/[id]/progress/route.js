var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/episodes/[id]/progress/route.js")
R.c("server/chunks/node_modules_next_2fe5547c._.js")
R.c("server/chunks/[root-of-the-server]__4189d64d._.js")
R.c("server/chunks/0da96_web__next-internal_server_app_api_episodes_[id]_progress_route_actions_14783653.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/apps/web/app/api/episodes/[id]/progress/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/apps/web/app/api/episodes/[id]/progress/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
