var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/episodes/[id]/watch/route.js")
R.c("server/chunks/node_modules_next_ae01bfdc._.js")
R.c("server/chunks/[root-of-the-server]__099c2ce0._.js")
R.c("server/chunks/0da96_web__next-internal_server_app_api_episodes_[id]_watch_route_actions_40880c5b.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/apps/web/app/api/episodes/[id]/watch/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/apps/web/app/api/episodes/[id]/watch/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
