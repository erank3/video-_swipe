var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/episodes/feed/route.js")
R.c("server/chunks/node_modules_next_f04c2d04._.js")
R.c("server/chunks/[root-of-the-server]__08814c9b._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_episodes_feed_route_actions_a3a3e74d.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/apps/web/app/api/episodes/feed/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/apps/web/app/api/episodes/feed/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
