var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/series/[id]/route.js")
R.c("server/chunks/node_modules_next_6e9e4d14._.js")
R.c("server/chunks/[root-of-the-server]__4f91f462._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_series_[id]_route_actions_88139103.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/apps/web/app/api/series/[id]/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/apps/web/app/api/series/[id]/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
