var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/series/route.js")
R.c("server/chunks/node_modules_next_27c1ce89._.js")
R.c("server/chunks/[root-of-the-server]__a92b70ab._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_series_route_actions_f17e7e50.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/apps/web/app/api/series/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/apps/web/app/api/series/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
