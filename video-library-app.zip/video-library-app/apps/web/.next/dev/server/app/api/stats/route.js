var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/stats/route.js")
R.c("server/chunks/node_modules_next_eb3c22e4._.js")
R.c("server/chunks/[root-of-the-server]__efcea713._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_stats_route_actions_2bf9f9c6.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/apps/web/app/api/stats/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/apps/web/app/api/stats/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
