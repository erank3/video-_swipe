module.exports = [
"[project]/apps/web/.next-internal/server/app/api/achievements/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=apps_web__next-internal_server_app_api_achievements_route_actions_e311976f.js.map