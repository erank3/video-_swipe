module.exports = [
"[project]/apps/web/.next-internal/server/app/api/series/[id]/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=apps_web__next-internal_server_app_api_series_%5Bid%5D_route_actions_88139103.js.map