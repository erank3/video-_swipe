module.exports = [
"[project]/apps/web/.next-internal/server/app/api/series/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=apps_web__next-internal_server_app_api_series_route_actions_f17e7e50.js.map